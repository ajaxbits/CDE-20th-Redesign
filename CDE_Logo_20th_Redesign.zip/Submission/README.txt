SOME NOTES:
-----------
- Find different sizes in the "Sizes" folder.
- Two copies of each version. PNG has a transparent background.
- Use PNGs, generally, on the website.
- The original Illustrator file and vector art are available 
  for you to modify if needed.

© (for commercial use with modification) Alex Jackson, 2020
